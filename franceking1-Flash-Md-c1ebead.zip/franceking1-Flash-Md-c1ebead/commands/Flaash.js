

/** 

🇫‌🇱‌🇦‌🇸‌🇭‌-🇲‌🇩‌ 

  𝗖𝗼𝗽𝘆𝗿𝗶𝗴𝗵𝘁 (𝗖) 2024.
 𝗟𝗶𝗰𝗲𝗻𝘀𝗲𝗱 𝘂𝗻𝗱𝗲𝗿 𝘁𝗵𝗲  𝗠𝗜𝗧 𝗟𝗶𝗰𝗲𝗻𝘀𝗲;
 𝗬𝗼𝘂 𝗺𝗮𝘆 𝗻𝗼𝘁 𝘂𝘀𝗲 𝘁𝗵𝗶𝘀 𝗳𝗶𝗹𝗲 𝗲𝘅𝗰𝗲𝗽𝘁 𝗶𝗻 𝗰𝗼𝗺𝗽𝗹𝗶𝗮𝗻𝗰𝗲 𝘄𝗶𝘁𝗵 𝘁𝗵𝗲 𝗟𝗶𝗰𝗲𝗻𝘀𝗲.
 𝗜𝘁 𝗶𝘀 𝘀𝘂𝗽𝗽𝗹𝗶𝗲𝗱 𝗶𝗻 𝘁𝗵𝗲 𝗵𝗼𝗽𝗲 𝘁𝗵𝗮𝘁 𝗶𝘁 𝗺𝗮𝘆 𝗯𝗲 𝘂𝘀𝗲𝗳𝘂𝗹.
 * @𝗽𝗿𝗼𝗷𝗲𝗰𝘁_𝗻𝗮𝗺𝗲 : 𝗙𝗹𝗮𝘀𝗵 𝗠𝗗, 𝗮 𝘀𝗶𝗺𝗽𝗹𝗲 𝗮𝗻𝗱 𝗲𝗮𝘀𝘆 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 𝘂𝘀𝗲𝗿 𝗯𝗼𝘁 
 * @𝗼𝘄𝗻𝗲𝗿: 𝗙𝗿𝗮𝗻𝗰𝗲 𝗞𝗶𝗻𝗴 
 
 **/





'use strict';const _0x3da531=_0x425c;(function(_0xd6778e,_0x4fd384){const _0x4060a1=_0x425c,_0x4ea66a=_0xd6778e();while(!![]){try{const _0x468670=parseInt(_0x4060a1(0xda))/0x1*(parseInt(_0x4060a1(0xdc))/0x2)+-parseInt(_0x4060a1(0xd6))/0x3*(parseInt(_0x4060a1(0xe3))/0x4)+parseInt(_0x4060a1(0xe1))/0x5*(-parseInt(_0x4060a1(0xdb))/0x6)+parseInt(_0x4060a1(0xd4))/0x7+-parseInt(_0x4060a1(0xd8))/0x8*(-parseInt(_0x4060a1(0xe0))/0x9)+-parseInt(_0x4060a1(0xd9))/0xa*(parseInt(_0x4060a1(0xd0))/0xb)+parseInt(_0x4060a1(0xde))/0xc;if(_0x468670===_0x4fd384)break;else _0x4ea66a['push'](_0x4ea66a['shift']());}catch(_0x1832ab){_0x4ea66a['push'](_0x4ea66a['shift']());}}}(_0x432a,0x841fc));function _0x432a(){const _0x400937=['../framework/france','332JEbIkU','__esModule','mon\x20test','https://whatsapp.com/channel/0029VacpEdXIt5rqKLB9nC1L','log','sendMessage','wagroup','6421492ueaOAC','Commande\x20saisie\x20!!!s','3183aZuRXV','Hello\x20🙂\x0a\x0aClick\x20The\x20link\x20below\x20to\x20Join\x20the\x20OFFICIAL\x20*FLASH-MD*\x20WhatsApp\x20Channel.\x0a\x0a','376czhBYk','489460cnPZmY','4639gIXFAQ','342nNNTal','130POBlcP','https://chat.whatsapp.com/IH4xWuVTGpf7ibfzC3h6LM','16708284tdgbGX','Hello\x20🙂\x0a\x0aClick\x20The\x20link\x20below\x20to\x20Join\x20the\x20OFFICIAL\x20*FLASH-MD*\x20WhatsApp\x20Group\x0a\x0a','25731fkOrko','91190TNizar'];_0x432a=function(){return _0x400937;};return _0x432a();}Object['defineProperty'](exports,_0x3da531(0xe4),{'value':!![]});function _0x425c(_0x4478f2,_0x3985d4){const _0x432a5c=_0x432a();return _0x425c=function(_0x425cf5,_0x461007){_0x425cf5=_0x425cf5-0xce;let _0x5a4d1d=_0x432a5c[_0x425cf5];return _0x5a4d1d;},_0x425c(_0x4478f2,_0x3985d4);}const {france}=require(_0x3da531(0xe2));france({'nomCom':_0x3da531(0xd3),'reaction'🤖'','nomFichier':__filename},async(_0x178233,_0x56dc7d,_0x27aadc)=>{const _0x2207a7=_0x3da531;console[_0x2207a7(0xd1)](_0x2207a7(0xd5));let _0x933d8e=_0x2207a7(0xdf),_0x14ca84=_0x2207a7(0xdd),_0x1a7224=_0x933d8e+_0x14ca84;var _0x172263='https://telegra.ph/file/6771f559b5e3138ee8610.jpg';await _0x56dc7d[_0x2207a7(0xd2)](_0x178233,{'image':{'url':_0x172263},'caption':_0x1a7224});}),console[_0x3da531(0xd1)](_0x3da531(0xce)),france({'nomCom':'channel','reaction':'🤍','nomFichier':__filename},async(_0xe689b2,_0x262c60,_0x5a0d3a)=>{const _0x4c4871=_0x3da531;console['log'](_0x4c4871(0xd5));let _0x2f31fc=_0x4c4871(0xd7),_0x29242c=_0x4c4871(0xcf),_0x3a5888=_0x2f31fc+_0x29242c;var _0x4e7804='https://telegra.ph/file/6771f559b5e3138ee8610.jpg';await _0x262c60[_0x4c4871(0xd2)](_0xe689b2,{'image':{'url':_0x4e7804},'caption':_0x3a5888});}),console[_0x3da531(0xd1)]('mon\x20test');
